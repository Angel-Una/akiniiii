window.switchStatsTab = function(tab) {
    var statsPanel = document.getElementById('stats-panel');
    var favoritesPanel = document.getElementById('favorites-panel');
    var searchPanel = document.getElementById('search-panel');
    var wordcloudPanel = document.getElementById('wordcloud-panel');
    var timelinePanel = document.getElementById('timeline-panel');
    var allBtns = document.querySelectorAll('.stats-nav-btn');
    allBtns.forEach(function(b) { b.classList.remove('active'); });
    var activeBtn = document.querySelector('.stats-nav-btn[data-tab="' + tab + '"]');
    if (activeBtn) activeBtn.classList.add('active');

    if (statsPanel) statsPanel.style.display = 'none';
    if (favoritesPanel) favoritesPanel.style.display = 'none';
    if (searchPanel) searchPanel.style.display = 'none';
    if (wordcloudPanel) wordcloudPanel.style.display = 'none';
    if (timelinePanel) timelinePanel.style.display = 'none';

    if (tab === 'stats') {
        if (statsPanel) statsPanel.style.display = 'block';
    } else if (tab === 'search') {
        if (searchPanel) searchPanel.style.display = 'block';
        setTimeout(function() {
            var inp = document.getElementById('msg-search-input');
            if (inp) inp.focus();
        }, 100);
    } else if (tab === 'wordcloud') {
        if (wordcloudPanel) wordcloudPanel.style.display = 'block';
        requestAnimationFrame(function() {
            if (typeof renderWordCloud === 'function') renderWordCloud();
        });
    } else if (tab === 'timeline') {
        if (timelinePanel) timelinePanel.style.display = 'block';
        requestAnimationFrame(function() {
            if (typeof renderMsgTimeline === 'function') renderMsgTimeline();
        });
    } else {
        if (favoritesPanel) favoritesPanel.style.display = 'block';
        if (typeof renderFavorites === 'function') renderFavorites();
    }
};

var groupChatSettings = (function() {
    try {
        var saved = JSON.parse(localStorage.getItem('groupChatSettings') || 'null');
        if (!saved) return { enabled: false, showAvatar: true, showName: true, members: [] };
        if (!saved.members) saved.members = [];
        return saved;
    } catch(e) { return { enabled: false, showAvatar: true, showName: true, members: [] }; }
})();
(function loadGroupAvatars() {
    if (!window.localforage) return;
    var members = groupChatSettings.members || [];
    if (members.length === 0) return;
    var promises = members.map(function(m, i) {
        var ref = m.avatarRef || (m.id ? 'gca_' + m.id : 'gca_' + i);
        return localforage.getItem(ref).then(function(avatar) {
            m.avatar = avatar || null;
        }).catch(function() { m.avatar = null; });
    });
    Promise.all(promises).then(function() {
        if (typeof renderGroupMembersList === 'function') renderGroupMembersList();
    });
})();
var _groupMemberAvatarDataUrl = null;

function saveGroupChatSettings() {
    var members = groupChatSettings.members || [];
    var toSave = {
        enabled: groupChatSettings.enabled,
        showAvatar: groupChatSettings.showAvatar,
        showName: groupChatSettings.showName,
        members: members.map(function(m) {
            if (!m.id) m.id = 'gcm_' + Date.now() + '_' + Math.random().toString(36).slice(2,7);
            return { name: m.name, id: m.id, avatarRef: 'gca_' + m.id };
        })
    };
    try {
        localStorage.setItem('groupChatSettings', JSON.stringify(toSave));
    } catch(e) {
        console.warn('groupChatSettings localStorage保存失败:', e);
    }
    if (window.localforage) {
        members.forEach(function(m) {
            if (!m.id) m.id = 'gcm_' + Date.now() + '_' + Math.random().toString(36).slice(2,7);
            localforage.setItem('gca_' + m.id, m.avatar || null).catch(function(e) {
                console.warn('头像存储失败 id=' + m.id, e);
            });
        });
    }
}

function renderGroupMembersList() {
    var list = document.getElementById('group-members-list');
    if (!list) return;
    if (!groupChatSettings.members || groupChatSettings.members.length === 0) {
        list.innerHTML = '<div style="text-align:center;padding:20px;color:var(--text-secondary);font-size:13px;">暂无成员，点击添加按钮添加</div>';
        return;
    }
    list.innerHTML = groupChatSettings.members.map(function(m, i) {
        var avatarHtml = m.avatar
            ? '<img src="' + m.avatar + '" style="width:36px;height:36px;border-radius:50%;object-fit:cover;">'
            : '<div style="width:36px;height:36px;border-radius:50%;background:rgba(var(--accent-color-rgb),0.15);display:flex;align-items:center;justify-content:center;"><i class="fas fa-user" style="font-size:14px;color:var(--accent-color);"></i></div>';
        return '<div style="display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--primary-bg);border:1px solid var(--border-color);border-radius:10px;">'
            + avatarHtml
            + '<span style="flex:1;font-size:13px;font-weight:500;">' + (m.name || '成员' + (i+1)) + '</span>'
            + '<button onclick="openEditGroupMember(' + i + ')" style="background:none;border:none;cursor:pointer;color:var(--accent-color);font-size:14px;padding:4px 8px;"><i class="fas fa-edit"></i></button>'
            + '<button onclick="deleteGroupMember(' + i + ')" style="background:none;border:none;cursor:pointer;color:#ff4757;font-size:14px;padding:4px 8px;"><i class="fas fa-trash-alt"></i></button>'
            + '</div>';
    }).join('');
}

function updateGroupModeUI() {
    var pill = document.getElementById('group-mode-pill');
    var knob = document.getElementById('group-mode-knob');
    var status = document.getElementById('group-mode-status');
    var displaySection = document.getElementById('group-display-section');
    var membersSection = document.getElementById('group-members-section');
    if (!pill) return;
    if (groupChatSettings.enabled) {
        pill.style.background = 'var(--accent-color)';
        knob.style.left = '22px';
        status.textContent = '已开启 — 收到的消息随机显示成员';
        displaySection.style.display = 'block';
        membersSection.style.display = 'block';
    } else {
        pill.style.background = 'var(--border-color)';
        knob.style.left = '3px';
        status.textContent = '已关闭 — 点击开启';
        displaySection.style.display = 'none';
        membersSection.style.display = 'none';
    }
    var avatarPill = document.getElementById('group-show-avatar-pill');
    var avatarKnob = document.getElementById('group-show-avatar-knob');
    if (avatarPill) {
        avatarPill.style.background = groupChatSettings.showAvatar ? 'var(--accent-color)' : 'var(--border-color)';
        avatarKnob.style.right = groupChatSettings.showAvatar ? '3px' : '19px';
    }
    var namePill = document.getElementById('group-show-name-pill');
    var nameKnob = document.getElementById('group-show-name-knob');
    if (namePill) {
        namePill.style.background = groupChatSettings.showName ? 'var(--accent-color)' : 'var(--border-color)';
        nameKnob.style.right = groupChatSettings.showName ? '3px' : '19px';
    }
    renderGroupMembersList();
}

document.addEventListener('DOMContentLoaded', function() {
    var groupModeToggle = document.getElementById('group-mode-toggle');
    if (groupModeToggle) {
        groupModeToggle.addEventListener('click', function() {
            groupChatSettings.enabled = !groupChatSettings.enabled;
            saveGroupChatSettings();
            updateGroupModeUI();
        });
    }
    var showAvatarToggle = document.getElementById('group-show-avatar-toggle');
    if (showAvatarToggle) {
        showAvatarToggle.addEventListener('click', function() {
            groupChatSettings.showAvatar = !groupChatSettings.showAvatar;
            saveGroupChatSettings();
            updateGroupModeUI();
        });
    }
    var showNameToggle = document.getElementById('group-show-name-toggle');
    if (showNameToggle) {
        showNameToggle.addEventListener('click', function() {
            groupChatSettings.showName = !groupChatSettings.showName;
            saveGroupChatSettings();
            updateGroupModeUI();
        });
    }
    var closeGroupChat = document.getElementById('close-group-chat');
    if (closeGroupChat) {
        closeGroupChat.addEventListener('click', function() {
            var m = document.getElementById('group-chat-modal');
            if (m && typeof hideModal === 'function') hideModal(m);
        });
    }
    setTimeout(updateGroupModeUI, 200);
});

window.openAddGroupMember = function() {
    _groupMemberAvatarDataUrl = null;
    document.getElementById('group-member-edit-title').textContent = '添加成员';
    document.getElementById('group-member-name-input').value = '';
    document.getElementById('group-member-edit-index').value = '';
    var preview = document.getElementById('group-member-avatar-preview');
    preview.innerHTML = '<i class="fas fa-camera" style="font-size:20px;color:var(--text-secondary);"></i>';
    var m = document.getElementById('group-member-edit-modal');
    if (m && typeof showModal === 'function') showModal(m);
};

window.openEditGroupMember = function(idx) {
    var member = groupChatSettings.members[idx];
    if (!member) return;
    _groupMemberAvatarDataUrl = member.avatar || null;
    document.getElementById('group-member-edit-title').textContent = '编辑成员';
    document.getElementById('group-member-name-input').value = member.name || '';
    document.getElementById('group-member-edit-index').value = idx;
    var preview = document.getElementById('group-member-avatar-preview');
    if (member.avatar) {
        preview.innerHTML = '<img src="' + member.avatar + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">';
    } else {
        preview.innerHTML = '<i class="fas fa-camera" style="font-size:20px;color:var(--text-secondary);"></i>';
    }
    var m = document.getElementById('group-member-edit-modal');
    if (m && typeof showModal === 'function') showModal(m);
};

window.closeGroupMemberEdit = function() {
    var m = document.getElementById('group-member-edit-modal');
    if (m && typeof hideModal === 'function') hideModal(m);
};

window.previewGroupMemberAvatar = function(input) {
    var file = input.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function(e) {
        _groupMemberAvatarDataUrl = e.target.result;
        var preview = document.getElementById('group-member-avatar-preview');
        preview.innerHTML = '<img src="' + e.target.result + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">';
    };
    reader.readAsDataURL(file);
};

window.saveGroupMember = function() {
    var name = (document.getElementById('group-member-name-input').value || '').trim();
    if (!name) { alert('请输入成员名字'); return; }
    var idxVal = document.getElementById('group-member-edit-index').value;
    var member = { name: name, avatar: _groupMemberAvatarDataUrl };
    if (idxVal !== '') {
        groupChatSettings.members[parseInt(idxVal)] = member;
    } else {
        if (!groupChatSettings.members) groupChatSettings.members = [];
        groupChatSettings.members.push(member);
    }
    saveGroupChatSettings();
    renderGroupMembersList();
    window.closeGroupMemberEdit();
};

window.deleteGroupMember = function(idx) {
    if (!confirm('确定删除该成员吗？')) return;
    groupChatSettings.members.splice(idx, 1);
    saveGroupChatSettings();
    renderGroupMembersList();
};

window.getGroupMemberForMessage = function(msgId) {
    if (!groupChatSettings.enabled || !groupChatSettings.members || groupChatSettings.members.length === 0) return null;
    var seed = 0;
    var idStr = String(msgId);
    for (var i = 0; i < idStr.length; i++) seed += idStr.charCodeAt(i) * (i + 1);
    return groupChatSettings.members[seed % groupChatSettings.members.length];
};

document.addEventListener('DOMContentLoaded', function() {
    var exportAllBtn = document.getElementById('export-all-settings');
    var importAllBtn = document.getElementById('import-all-settings');
if (exportAllBtn) {
        exportAllBtn.addEventListener('click', async function() {
            const overlay = document.createElement('div');
            overlay.style.cssText = 'position:fixed;inset:0;z-index:99999999;background:rgba(0,0,0,0.55);backdrop-filter:blur(8px);display:flex;align-items:center;justify-content:center;animation:fadeIn 0.2s ease;';
            overlay.innerHTML = `
                <div style="background:var(--secondary-bg);border-radius:20px;padding:24px;width:88%;max-width:380px;box-shadow:0 20px 60px rgba(0,0,0,0.4);animation:modalContentSlideIn 0.3s ease forwards;">
                    <div style="font-size:15px;font-weight:700;color:var(--text-primary);margin-bottom:4px;display:flex;align-items:center;gap:8px;">
                        <i class="fas fa-archive" style="color:var(--accent-color);font-size:14px;"></i>全量备份导出
                    </div>
                    <div style="font-size:12px;color:var(--text-secondary);margin-bottom:16px;">默认导出为 <strong>ZIP</strong>：<code style="font-size:11px;">backup.json</code> 仅存结构与引用，大图在 <code style="font-size:11px;">media/</code>，避免单文件 JSON 过大导致无法解析。</div>
                    <div style="display:flex;flex-direction:column;gap:9px;margin-bottom:20px;">
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_msgs" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-comments" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>聊天记录 <span style="font-size:11px;color:var(--text-secondary);">(${messages.length} 条)</span></span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_settings" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-sliders-h" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>外观与聊天设置</span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_custom" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-reply" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>字卡 / 拍一拍 / 状态 / 格言</span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_ann" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-calendar-heart" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>纪念日 / 倒计时</span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_themes" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-palette" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>自定义主题 / 方案</span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_dg" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-sun" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>每日公告 / 心情数据</span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_stickers" style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-sticky-note" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>表情库 <span style="font-size:11px;color:var(--text-secondary);">(默认关，勾选后去重打包)</span></span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_home" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-home" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>Home美化</span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_moyu" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-briefcase" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>摸鱼小记</span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_shop" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-shopping-bag" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>商城 / 礼物柜</span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_moments" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-camera" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>朋友圈 / 访客记录</span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_map" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-map-marked-alt" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>Zmilk地图</span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_taphone" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-mobile-alt" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>TA的手机</span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_pet" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-paw" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>萌宠屋 / 像素宠物</span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_diary" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-book" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>朝夕心记</span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_accounting" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-calculator" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>同心记账</span>
                        </label>
                        <label style="display:flex;align-items:center;gap:10px;cursor:pointer;padding:10px 12px;border:1px solid var(--border-color);border-radius:12px;background:var(--primary-bg);font-size:13px;color:var(--text-primary);">
                            <input type="checkbox" id="_bk_envelope" checked style="accent-color:var(--accent-color);width:15px;height:15px;">
                            <i class="fas fa-envelope" style="color:var(--accent-color);width:16px;text-align:center;"></i>
                            <span>信封投递</span>
                        </label>
                    </div>
                    <div style="display:flex;gap:10px;">
                        <button id="_bk_cancel" style="flex:1;padding:11px;border:1px solid var(--border-color);border-radius:12px;background:none;color:var(--text-secondary);font-size:13px;cursor:pointer;font-family:var(--font-family);">取消</button>
                        <button id="_bk_confirm" style="flex:2;padding:11px;border:none;border-radius:12px;background:var(--accent-color);color:#fff;font-size:13px;font-weight:600;cursor:pointer;font-family:var(--font-family);display:flex;align-items:center;justify-content:center;gap:7px;">
                            <i class="fas fa-download"></i>导出备份
                        </button>
                    </div>
                </div>`;
            document.body.appendChild(overlay);

            function closeBkDialog() { overlay.remove(); }
            overlay.addEventListener('click', ev => { if (ev.target === overlay) closeBkDialog(); });
            const bkCancelBtn = document.getElementById('_bk_cancel');
            const bkConfirmBtn = document.getElementById('_bk_confirm');
            if (bkCancelBtn) bkCancelBtn.onclick = closeBkDialog;

            if (bkConfirmBtn) bkConfirmBtn.onclick = async function() {
                const inclMsgs    = document.getElementById('_bk_msgs').checked;
                const inclSet     = document.getElementById('_bk_settings').checked;
                const inclCustom  = document.getElementById('_bk_custom').checked;
                const inclAnn     = document.getElementById('_bk_ann').checked;
                const inclThemes  = document.getElementById('_bk_themes').checked;
                const inclDg      = document.getElementById('_bk_dg').checked;
                const inclStickers = document.getElementById('_bk_stickers') && document.getElementById('_bk_stickers').checked;
                const inclMoyu    = document.getElementById('_bk_moyu').checked;
                const inclHome    = document.getElementById('_bk_home').checked;
                const inclShop    = document.getElementById('_bk_shop').checked;
                const inclMoments = document.getElementById('_bk_moments').checked;
                const inclMap     = document.getElementById('_bk_map').checked;
                const inclTaPhone = document.getElementById('_bk_taphone').checked;
                const inclPet     = document.getElementById('_bk_pet').checked;
                const inclDiary   = document.getElementById('_bk_diary').checked;
                const inclAccounting = document.getElementById('_bk_accounting').checked;
                const inclEnvelope = document.getElementById('_bk_envelope').checked;

                if (!inclMsgs && !inclSet && !inclCustom && !inclAnn && !inclThemes && !inclDg && !inclStickers &&
                    !inclHome && !inclMoyu && !inclShop && !inclMoments && !inclMap && !inclTaPhone && !inclPet &&
                    !inclDiary && !inclAccounting && !inclEnvelope) {
                    showNotification('请至少选择一项', 'error');
                    return;
                }
                closeBkDialog();

                try {
                    if (typeof ChatBackup !== 'undefined' && ChatBackup.buildBackupPayload && ChatBackup.serializeBackupV4) {
                        const payload = await ChatBackup.buildBackupPayload({
                            inclMsgs: inclMsgs,
                            inclSet: inclSet,
                            inclCustom: inclCustom,
                            inclAnn: inclAnn,
                            inclThemes: inclThemes,
                            inclDg: inclDg,
                            inclStickers: inclStickers,
                            inclHome: inclHome,
                            inclMoyu: inclMoyu,
                            inclShop: inclShop,
                            inclMoments: inclMoments,
                            inclMap: inclMap,
                            inclTaPhone: inclTaPhone,
                            inclPet: inclPet,
                            inclDiary: inclDiary,
                            inclAccounting: inclAccounting,
                            inclEnvelope: inclEnvelope
                        });
                        const jsonString = ChatBackup.serializeBackupV4(payload);
                        const dateStr = new Date().toISOString().slice(0, 10);
                        const fileName = `chatapp-backup-${dateStr}.json`;
                        const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8' });
                        downloadFileFallback(blob, fileName);
                        if (typeof showNotification === 'function') showNotification('已导出 JSON 备份', 'success');
                    } else {
                        if (typeof showNotification === 'function') showNotification('备份模块或函数未加载，请刷新页面', 'error');
                    }
                } catch(e) {
                    console.error('全量备份导出失败:', e);
                    if (typeof showNotification === 'function') showNotification('导出失败，请重试', 'error');
                }
            };
        });
    }
if (importAllBtn) {
        importAllBtn.addEventListener('click', function() {
            var input = document.createElement('input');
            input.type = 'file';
            input.accept = '.json,.zip,application/json,application/zip';
            input.onchange = async function(e) {
                var file = e.target.files[0];
                if (!file) return;

                if (file.size > 220 * 1024 * 1024) {
                    if (typeof showNotification === 'function') showNotification('文件过大，请检查是否是正确的备份文件', 'error');
                    return;
                }

                try {
                    if (typeof ChatBackup === 'undefined' || !ChatBackup.loadBackupFromFile || !ChatBackup.applyBackupToStorage) {
                        throw new Error('备份模块未加载，请刷新页面');
                    }
                    var backup = await ChatBackup.loadBackupFromFile(file);

                    var okShape = backup.type === 'chatapp-backup-v5' ||
                        backup.type === 'full' ||
                        (backup.type && backup.type.indexOf('backup') !== -1) ||
                        backup.formatVersion === 4 ||
                        backup.formatVersion === 5 ||
                        backup.localforage ||
                        backup.indexedDB;
                    if (!okShape) throw new Error('不是有效的传讯备份文件');

                    if (!confirm('导入全量备份将覆盖备份文件中包含的数据（按文件内容写入）。\n\nv5 ZIP：从 media/ 还原图片；v4 JSON：从 mediaStore 还原。\n\n确定继续吗？')) return;

                    await ChatBackup.applyBackupToStorage(backup, { selective: false });

                    if (typeof showNotification === 'function') showNotification('数据恢复成功，即将刷新页面应用更改', 'success', 2000);
                    setTimeout(function() { location.reload(); }, 2000);
                } catch (err) {
                    var msg = err && err.message ? err.message : '未知错误';
                    if (typeof showNotification === 'function') showNotification('导入失败：' + msg, 'error', 5000);
                    console.error('导入报错:', err);
                }
            };
            document.body.appendChild(input);
            input.click();
            document.body.removeChild(input);
        });
    }
});

window.startEditDgWeather = function(el) {
    var current = el.textContent.trim();
    var input = document.createElement('input');
    input.type = 'text';
    input.value = current;
    input.maxLength = 20;
    input.style.cssText = 'width:120px;padding:2px 6px;border:1px solid var(--accent-color);border-radius:6px;font-size:13px;background:var(--primary-bg);color:var(--text-primary);outline:none;';
    el.style.display = 'none';
    el.parentNode.insertBefore(input, el.nextSibling);
    input.focus();
    input.select();
    function saveWeather() {
        var val = input.value.trim() || current;
        el.textContent = val;
        el.style.display = '';
        input.remove();
        var now = new Date();
        var dateKey = 'customWeather_' + now.getFullYear() + '_' + (now.getMonth()+1) + '_' + now.getDate();
        localStorage.setItem(dateKey, val);
    }
    input.addEventListener('blur', saveWeather);
    input.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') { e.preventDefault(); saveWeather(); }
        if (e.key === 'Escape') { el.style.display = ''; input.remove(); }
    });
};

    document.addEventListener('focusin', function(e) {
        if (e.target && (e.target.classList.contains('message-input') || e.target.tagName === 'TEXTAREA')) {
            setTimeout(function() {
                var chat = document.querySelector('.chat-container');
                if (chat) chat.scrollTop = chat.scrollHeight;
            }, 100);
        }
    });


window._runMsgSearch = function() {
    var input = document.getElementById('msg-search-input');
    var dateFrom = document.getElementById('msg-search-date-from');
    var dateTo = document.getElementById('msg-search-date-to');
    var resultsEl = document.getElementById('msg-search-results');
    if (!input || !resultsEl) return;

    var q = input.value.trim().toLowerCase();
    var from = dateFrom && dateFrom.value ? new Date(dateFrom.value) : null;
    var to = dateTo && dateTo.value ? new Date(dateTo.value + 'T23:59:59') : null;

    var allMessages = (typeof messages !== 'undefined' ? messages : [])
        .filter(function(m) { return m.type !== 'system'; });

    var filtered = allMessages.filter(function(m) {
        var matchText = !q || (m.text && m.text.toLowerCase().includes(q)) || (m.image && !q);
        if (q && m.image && !m.text) matchText = false;
        if (q) matchText = m.text && m.text.toLowerCase().includes(q);
        var ts = m.timestamp ? new Date(m.timestamp) : null;
        var matchFrom = !from || (ts && ts >= from);
        var matchTo = !to || (ts && ts <= to);
        return matchText && matchFrom && matchTo;
    });

    if (!q && !from && !to) {
        resultsEl.innerHTML = '<div style="text-align:center;padding:24px;color:var(--text-secondary);font-size:13px;">输入关键词或选择日期开始搜索</div>';
        return;
    }

    if (filtered.length === 0) {
        resultsEl.innerHTML = '<div style="text-align:center;padding:24px;color:var(--text-secondary);font-size:13px;">未找到相关消息</div>';
        return;
    }

    var myAvatarEl = document.querySelector('#my-avatar img');
    var partnerAvatarEl = document.querySelector('#partner-avatar img');
    var myAvatar = myAvatarEl ? myAvatarEl.src : '';
    var partnerAvatar = partnerAvatarEl ? partnerAvatarEl.src : '';
    var myName = (typeof settings !== 'undefined' && settings.myName) || '我';
    var partnerName = (typeof settings !== 'undefined' && settings.partnerName) || '对方';

    function highlight(text) {
        if (!q || !text) return (text || '').replace(/</g,'&lt;').replace(/>/g,'&gt;');
        var safe = text.replace(/</g,'&lt;').replace(/>/g,'&gt;');
        var safeQ = q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        return safe.replace(new RegExp('(' + safeQ + ')', 'gi'), '<mark style="background:rgba(var(--accent-color-rgb,180,140,100),0.3);border-radius:2px;padding:0 1px;">$1</mark>');
    }

    resultsEl.innerHTML = filtered.map(function(msg) {
        var isUser = msg.sender === 'user';
        var name = isUser ? myName : partnerName;
        var avatar = isUser ? myAvatar : partnerAvatar;

        if (!isUser && typeof groupChatSettings !== 'undefined' && groupChatSettings.enabled && groupChatSettings.members) {
            var member = groupChatSettings.members.find(function(m) { return m.name === msg.sender; });
            if (member) {
                name = member.name;
                avatar = member.avatar || '';
            }
        }

        var ts = msg.timestamp ? new Date(msg.timestamp).toLocaleString('zh-CN', {
            month:'2-digit', day:'2-digit', hour:'2-digit', minute:'2-digit'
        }) : '';

        var avatarHtml = avatar
            ? '<img src="' + avatar + '" style="width:34px;height:34px;border-radius:50%;object-fit:cover;flex-shrink:0;">'
            : '<div style="width:34px;height:34px;border-radius:50%;background:rgba(var(--accent-color-rgb,180,140,100),0.18);display:flex;align-items:center;justify-content:center;flex-shrink:0;"><i class="fas fa-user" style="font-size:14px;color:var(--accent-color);"></i></div>';

        var contentHtml = '';
        if (msg.text) contentHtml += '<div style="font-size:13px;color:var(--text-primary);line-height:1.5;word-break:break-word;margin-top:3px;">' + highlight(msg.text) + '</div>';
        if (msg.image) contentHtml += '<img src="' + msg.image + '" style="max-width:120px;max-height:90px;border-radius:8px;display:block;margin-top:5px;cursor:pointer;" onclick="if(typeof viewImage===\'function\')viewImage(\'' + msg.image.replace(/'/g,"\\'") + '\')" loading="lazy">';

        return '<div style="display:flex;align-items:flex-start;gap:10px;padding:10px 12px;border-radius:12px;background:var(--primary-bg);border:1px solid var(--border-color);margin-bottom:8px;cursor:pointer;" onclick="if(typeof scrollToMessage===\'function\')scrollToMessage(' + msg.id + ')">'
            + avatarHtml
            + '<div style="flex:1;min-width:0;">'
            + '<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;">'
            + '<span style="font-size:12px;font-weight:600;color:var(--accent-color);">' + name + '</span>'
            + '<span style="font-size:11px;color:var(--text-secondary);white-space:nowrap;">' + ts + '</span>'
            + '</div>'
            + contentHtml
            + '</div></div>';
    }).join('');

    resultsEl.insertAdjacentHTML('afterbegin',
        '<div style="font-size:12px;color:var(--text-secondary);margin-bottom:8px;padding:0 2px;">共找到 ' + filtered.length + ' 条结果</div>'
    );
};

window.scrollToMessage = function(msgId) {
    // 关闭统计弹窗（hideModal 可能不在全局作用域，直接操作 DOM）
    var statsModal = document.getElementById('stats-modal');
    if (statsModal) {
        var content = statsModal.querySelector('.modal-content');
        if (content) {
            content.style.opacity = '0';
            content.style.transform = 'translateY(20px) scale(0.95)';
        }
        if (statsModal._hideTimeout) clearTimeout(statsModal._hideTimeout);
        statsModal._hideTimeout = setTimeout(function() {
            statsModal.style.display = 'none';
        }, 300);
    }

    // 延迟等弹窗关闭动画完成，再尝试滚动
    setTimeout(function() {
        var el = document.querySelector('[data-id="' + msgId + '"]') || document.querySelector('[data-msg-id="' + msgId + '"]');

        if (el) {
            // 消息已在 DOM 中，直接滚动
            el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            el.style.transition = 'background 0.3s';
            el.style.background = 'rgba(var(--accent-color-rgb,180,140,100),0.18)';
            setTimeout(function() { el.style.background = ''; }, 1500);
        } else {
            // 消息不在当前视图中，需要加载更多历史消息
            var msgIndex = -1;
            if (typeof messages !== 'undefined') {
                for (var i = 0; i < messages.length; i++) {
                    if (String(messages[i].id) === String(msgId)) {
                        msgIndex = i;
                        break;
                    }
                }
            }
            if (msgIndex === -1) {
                if (typeof showNotification === 'function') showNotification('消息可能已被删除', 'info');
                return;
            }
            // 增加显示的消息数量以包含目标消息
            if (typeof displayedMessageCount !== 'undefined') {
                var needed = messages.length - msgIndex;
                if (needed > displayedMessageCount) {
                    displayedMessageCount = needed + 10; // 多加载一些
                    if (typeof renderMessages === 'function') renderMessages(false);
                    // 渲染完成后再尝试滚动
                    setTimeout(function() {
                        var el2 = document.querySelector('[data-id="' + msgId + '"]') || document.querySelector('[data-msg-id="' + msgId + '"]');
                        if (el2) {
                            el2.scrollIntoView({ behavior: 'smooth', block: 'center' });
                            el2.style.transition = 'background 0.3s';
                            el2.style.background = 'rgba(var(--accent-color-rgb,180,140,100),0.18)';
                            setTimeout(function() { el2.style.background = ''; }, 1500);
                        } else {
                            if (typeof showNotification === 'function') showNotification('消息定位失败', 'info');
                        }
                    }, 200);
                }
            }
        }
    }, 350);
};

/* ===== 消息统计 - 日历热力图时间轴 ===== */
(function() {
    var _tlYear = new Date().getFullYear();
    var _tlMonth = new Date().getMonth(); // 0-based

    // 根据消息数量返回热力图颜色（从浅到深，5级）
    function getHeatColor(count, maxCount) {
        if (count === 0) return 'transparent';
        var ratio = maxCount > 0 ? count / maxCount : 0;
        if (ratio <= 0) return 'rgba(var(--accent-color-rgb, 180,140,100), 0.08)';
        if (ratio <= 0.2) return 'rgba(var(--accent-color-rgb, 180,140,100), 0.2)';
        if (ratio <= 0.4) return 'rgba(var(--accent-color-rgb, 180,140,100), 0.4)';
        if (ratio <= 0.7) return 'rgba(var(--accent-color-rgb, 180,140,100), 0.65)';
        return 'rgba(var(--accent-color-rgb, 180,140,100), 0.9)';
    }

    // 统计每天的消息数量
    function countMessagesByDay(year, month) {
        var counts = {};
        var firstDay = new Date(year, month, 1);
        var lastDay = new Date(year, month + 1, 0);
        var firstDayTime = firstDay.getTime();
        var lastDayTime = lastDay.getTime() + 86400000 - 1; // 包含最后一天

        if (typeof messages !== 'undefined' && messages.length > 0) {
            messages.forEach(function(msg) {
                if (msg.timestamp && msg.type !== 'system') {
                    var t = new Date(msg.timestamp).getTime();
                    if (t >= firstDayTime && t <= lastDayTime) {
                        var d = new Date(msg.timestamp);
                        var key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
                        counts[key] = (counts[key] || 0) + 1;
                    }
                }
            });
        }
        return counts;
    }

    // 获取某天的第一条消息ID
    function getFirstMsgIdOfDay(dateStr) {
        if (typeof messages === 'undefined' || messages.length === 0) return null;
        for (var i = 0; i < messages.length; i++) {
            var msg = messages[i];
            if (msg.timestamp && msg.type !== 'system') {
                var d = new Date(msg.timestamp);
                var key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
                if (key === dateStr) return msg.id;
            }
        }
        return null;
    }

    window.renderMsgTimeline = function() {
        var container = document.getElementById('timeline-container');
        if (!container) return;

        var counts = countMessagesByDay(_tlYear, _tlMonth);
        var values = Object.values(counts);
        var maxCount = values.length > 0 ? Math.max.apply(null, values) : 1;

        var year = _tlYear;
        var month = _tlMonth;
        var firstDayOfMonth = new Date(year, month, 1);
        var lastDayOfMonth = new Date(year, month + 1, 0);
        var startWeekday = firstDayOfMonth.getDay(); // 0=周日
        var daysInMonth = lastDayOfMonth.getDate();

        var today = new Date();
        var todayStr = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');

        var monthNames = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];

        // 计算总消息数
        var totalMonthMsgs = values.reduce(function(a, b) { return a + b; }, 0);
        // 计算活跃天数
        var activeDays = values.filter(function(v) { return v > 0; }).length;

        var html = '';
        // 头部导航
        html += '<div class="tl-calendar-header">';
        html += '  <button class="tl-cal-nav-btn" id="tl-prev-month"><i class="fas fa-chevron-left"></i></button>';
        html += '  <div class="tl-month-label">' + year + '年 ' + monthNames[month] + '</div>';
        html += '  <button class="tl-cal-nav-btn" id="tl-next-month"><i class="fas fa-chevron-right"></i></button>';
        html += '</div>';

        // 概览统计
        html += '<div class="tl-summary-row">';
        html += '  <div class="tl-summary-item"><span class="tl-summary-value">' + totalMonthMsgs + '</span><span class="tl-summary-label">条消息</span></div>';
        html += '  <div class="tl-summary-item"><span class="tl-summary-value">' + activeDays + '</span><span class="tl-summary-label">天活跃</span></div>';
        html += '  <div class="tl-summary-item"><span class="tl-summary-value">' + (activeDays > 0 ? Math.round(totalMonthMsgs / activeDays) : 0) + '</span><span class="tl-summary-label">日均</span></div>';
        html += '</div>';

        // 星期标题
        html += '<div class="tl-cal-weekdays">';
        html += '  <div>日</div><div>一</div><div>二</div><div>三</div><div>四</div><div>五</div><div>六</div>';
        html += '</div>';

        // 日历网格
        html += '<div class="tl-cal-grid">';
        // 填充前面的空白
        for (var i = 0; i < startWeekday; i++) {
            html += '<div class="tl-cal-day empty"></div>';
        }
        // 填充每一天
        for (var day = 1; day <= daysInMonth; day++) {
            var dateStr = year + '-' + String(month + 1).padStart(2, '0') + '-' + String(day).padStart(2, '0');
            var count = counts[dateStr] || 0;
            var bgColor = getHeatColor(count, maxCount);
            var isToday = (dateStr === todayStr);
            var hasMsg = count > 0;
            var firstId = hasMsg ? getFirstMsgIdOfDay(dateStr) : null;

            var classes = 'tl-cal-day';
            if (isToday) classes += ' today';
            if (hasMsg) classes += ' has-msg';

            html += '<div class="' + classes + '" data-date="' + dateStr + '" data-count="' + count + '"';
            if (firstId) {
                html += ' onclick="window._jumpToDayMsg(' + firstId + ')"';
            }
            html += ' style="background-color:' + bgColor + ';">';
            html += '  <span class="tl-day-num">' + day + '</span>';
            if (hasMsg) {
                html += '  <span class="tl-day-count">' + count + '</span>';
            }
            html += '</div>';
        }
        html += '</div>';

        // 图例
        html += '<div class="tl-legend">';
        html += '  <span class="tl-legend-label">少</span>';
        html += '  <div class="tl-legend-block" style="background:rgba(var(--accent-color-rgb,180,140,100),0.08);"></div>';
        html += '  <div class="tl-legend-block" style="background:rgba(var(--accent-color-rgb,180,140,100),0.2);"></div>';
        html += '  <div class="tl-legend-block" style="background:rgba(var(--accent-color-rgb,180,140,100),0.4);"></div>';
        html += '  <div class="tl-legend-block" style="background:rgba(var(--accent-color-rgb,180,140,100),0.65);"></div>';
        html += '  <div class="tl-legend-block" style="background:rgba(var(--accent-color-rgb,180,140,100),0.9);"></div>';
        html += '  <span class="tl-legend-label">多</span>';
        html += '</div>';

        container.innerHTML = html;

        // 绑定月份切换事件
        var prevBtn = document.getElementById('tl-prev-month');
        var nextBtn = document.getElementById('tl-next-month');
        if (prevBtn) prevBtn.onclick = function() {
            _tlMonth--;
            if (_tlMonth < 0) { _tlMonth = 11; _tlYear--; }
            renderMsgTimeline();
        };
        if (nextBtn) nextBtn.onclick = function() {
            _tlMonth++;
            if (_tlMonth > 11) { _tlMonth = 0; _tlYear++; }
            renderMsgTimeline();
        };
    };

    // 点击日期跳转到对应日期的第一条消息
    window._jumpToDayMsg = function(msgId) {
        // 关闭统计弹窗（hideModal 可能不在全局作用域，直接操作 DOM）
        var statsModal = document.getElementById('stats-modal');
        if (statsModal) {
            var content = statsModal.querySelector('.modal-content');
            if (content) {
                content.style.opacity = '0';
                content.style.transform = 'translateY(20px) scale(0.95)';
            }
            if (statsModal._hideTimeout) clearTimeout(statsModal._hideTimeout);
            statsModal._hideTimeout = setTimeout(function() {
                statsModal.style.display = 'none';
            }, 300);
        }

        // 延迟等弹窗关闭动画完成，再尝试滚动
        setTimeout(function() {
            var el = document.querySelector('[data-id="' + msgId + '"]') || document.querySelector('[data-msg-id="' + msgId + '"]');

            if (el) {
                // 消息已在 DOM 中，直接滚动
                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
                el.style.transition = 'background 0.3s';
                el.style.background = 'rgba(var(--accent-color-rgb,180,140,100),0.18)';
                setTimeout(function() { el.style.background = ''; }, 1500);
            } else {
                // 消息不在当前视图中，需要加载更多历史消息
                var msgIndex = -1;
                if (typeof messages !== 'undefined') {
                    for (var i = 0; i < messages.length; i++) {
                        if (String(messages[i].id) === String(msgId)) {
                            msgIndex = i;
                            break;
                        }
                    }
                }
                if (msgIndex === -1) {
                    if (typeof showNotification === 'function') showNotification('消息可能已被删除', 'info');
                    return;
                }
                // 增加显示的消息数量以包含目标消息
                if (typeof displayedMessageCount !== 'undefined') {
                    var needed = messages.length - msgIndex;
                    if (needed > displayedMessageCount) {
                        displayedMessageCount = needed + 10; // 多加载一些
                        if (typeof renderMessages === 'function') renderMessages(false);
                        // 渲染完成后再尝试滚动
                        setTimeout(function() {
                            var el2 = document.querySelector('[data-id="' + msgId + '"]') || document.querySelector('[data-msg-id="' + msgId + '"]');
                            if (el2) {
                                el2.scrollIntoView({ behavior: 'smooth', block: 'center' });
                                el2.style.transition = 'background 0.3s';
                                el2.style.background = 'rgba(var(--accent-color-rgb,180,140,100),0.18)';
                                setTimeout(function() { el2.style.background = ''; }, 1500);
                            } else {
                                if (typeof showNotification === 'function') showNotification('消息定位失败', 'info');
                            }
                        }, 200);
                    }
                }
            }
        }, 350);
    };
})();
