

// 长方圆角日历动态与系统同步更新
var _akiniCalDateKey = "";
window.updateS1Calendar = function (forceDay) {
  var now = new Date();

  /* 日历时间格式彻底与设置面板时间戳解绑！
     固定格式：12小时制 hh:mm:ss AM/PM，绝不重复拼接秒单位，绝不被设置时间戳覆盖 */
  var _rawH = now.getHours();
  var minutes = now.getMinutes();
  var seconds = now.getSeconds();
  var ampm = _rawH >= 12 ? "PM" : "AM";
  var hours12 = _rawH % 12;
  hours12 = hours12 ? hours12 : 12;
  var _hh = (hours12 < 10 ? "0" : "") + hours12;
  var _mm = (minutes < 10 ? "0" : "") + minutes;
  var _ss = (seconds < 10 ? "0" : "") + seconds;
  var timeStr = _hh + ":" + _mm + ":" + _ss + " " + ampm;

  var timeEl = document.getElementById("calLiveTime");
  if (timeEl && timeEl.textContent !== timeStr) timeEl.textContent = timeStr;

  // 日期与星期网格只在跨日或回前台校准时更新
  var year = now.getFullYear();
  var month = now.getMonth() + 1;
  var date = now.getDate();
  var dayIdx = now.getDay();
  var dateKey = year + "/" + month + "/" + date;
  if (!forceDay && dateKey === _akiniCalDateKey) return;
  _akiniCalDateKey = dateKey;

  var dateEl = document.getElementById("calLiveDate");
  if (dateEl && dateEl.textContent !== dateKey) dateEl.textContent = dateKey;

  var weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  var weekEl = document.getElementById("calLiveWeekday");
  if (weekEl && weekEl.textContent !== weekdays[dayIdx]) weekEl.textContent = weekdays[dayIdx];

  var items = document.querySelectorAll("#calWeekGrid .w-item");
  items.forEach(function (item) {
    var active = parseInt(item.getAttribute("data-w"), 10) === dayIdx;
    if (item.classList.contains("today-active") !== active) item.classList.toggle("today-active", active);
  });
};

window.editCalCustomText = function () {
  var el = document.getElementById("calCustomCenter");
  if (!el) return;
  var cur = el.textContent || "xxx";
  window.__akiniPromptModal(
    "日历中间自定义文字",
    "请输入自定义文字",
    function (val) {
      if (val !== null && String(val).trim() !== "") {
        var str = String(val).trim();
        el.textContent = str;
        try {
          localStorage.setItem("akini_cal_custom_center", str);
        } catch (e) {}
      }
    },
    { value: cur === "xxx" ? "" : cur, maxLength: 30 },
  );
};

/* 时间模块每秒刷新，确保永远实时；独立 IIFE 保护，不受其他启动脚本异常影响 */
(function () {
  function _tick(forceDay) {
    try {
      if (window.updateS1Calendar) window.updateS1Calendar(forceDay);
    } catch (e) {}
  }
  /* 自定义日历文字：DOM 就绪后回填，并在异步恢复完成后再应用一次 */
  window.__akiniApplyCalText = function () {
    try {
      var saved = localStorage.getItem("akini_cal_custom_center");
      if (saved) {
        var el = document.getElementById("calCustomCenter");
        if (el) el.textContent = saved;
      }
    } catch (e) {}
  };
  function _boot() {
    _tick(true);
    window.__akiniApplyCalText();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", _boot);
  else _boot();
  /* 每秒刷新日历时间，前台可见时持续走秒；后台自动暂停节省资源 */
  setInterval(function () {
    if (!document.hidden) _tick();
  }, 1000);
  // 前台可见时立即更新
  window.__akiniOnVisible(function () { _tick(true); });
  /* 设置里切换时间格式 → 日历立即按新格式刷新 */
  window.addEventListener("storage", function (ev) {
    try {
      if (ev && ev.key === "akini_timeFormat" && !document.hidden) _tick();
    } catch (e) {}
  });
  setTimeout(window.__akiniApplyCalText, 1200);
  setTimeout(window.__akiniApplyCalText, 3000);
  window.addEventListener("load", window.__akiniApplyCalText);
})();


/* 聊天设置菜单：打开/关闭 + 全局事件委托 */
window.openChatMenuModal = function () {
  var cmo = document.getElementById("chatMenuOverlay");
  if (!cmo) return;
  cmo.style.display = "flex";
  cmo.classList.add("show");
  cmo.style.pointerEvents = "auto";
  cmo.style.zIndex = "99999";
  try {
    window.__akiniSyncChatMenuUI();
  } catch (e) {}
};

window.closeChatMenuModal = function () {
  var cmo = document.getElementById("chatMenuOverlay");
  if (!cmo) return;
  cmo.style.display = "none";
  cmo.classList.remove("show");
  cmo.style.pointerEvents = "none";
};

document.addEventListener("click", function (e) {
  var t = e.target;
  if (!t || !t.closest) return;

  if (
    t.id === "menuBg" ||
    (t.classList && t.classList.contains("menu-bg")) ||
    t.id === "chatMenuOverlay" ||
    t.id === "mpCloseBtn"
  ) {
    window.closeChatMenuModal();
    return;
  }

  var menuBtn = t.closest("#chatContactMenuBtn, .chat-contact-menu-btn, #chatTaName, .ta-name-pill");
  if (menuBtn) {
    var appChat = document.getElementById("app-chat");
    if (appChat && appChat.style.display !== "none") window.openChatMenuModal();
    return;
  }

  var homeBtn = t.closest("#changeHomeBgBtnBeautify");
  if (homeBtn) {
    e.preventDefault();
    window.triggerPickImage("akini_home_bg", function (dataUrl) {
      if (window.__akiniSaveImageKey) window.__akiniSaveImageKey("akini_home_bg", dataUrl);
      else {
        try {
          localStorage.setItem("akini_home_bg", dataUrl);
        } catch (ex) {}
      }
      if (window.applyAkiniHomeBg) {
        window.applyAkiniHomeBg(dataUrl);
        return;
      }
      var el = document.getElementById("phoneFrame");
      if (el) el.style.setProperty("background-image", 'url("' + dataUrl + '")', "important");
    });
    return;
  }

  var friendsBtn = t.closest("#changeFriendsBgBtnBeautify");
  if (friendsBtn) {
    e.preventDefault();
    window.triggerPickImage("akini_friends_bg", function (dataUrl) {
      if (window.__akiniSaveImageKey) window.__akiniSaveImageKey("akini_friends_bg", dataUrl);
      else {
        try {
          localStorage.setItem("akini_friends_bg", dataUrl);
        } catch (ex) {}
      }
      var el = document.getElementById("friendsHeader");
      if (el) el.style.setProperty("background-image", 'url("' + dataUrl + '")', "important");
    });
  }
});

window.triggerPickImage = function (targetKey, callback) {
  var input = document.getElementById("akini_universal_picker");
  if (!input) {
    input = document.createElement("input");
    input.type = "file";
    input.accept = "image/*";
    input.id = "akini_universal_picker";
    input.style.cssText = "position:fixed;top:-9999px;left:-9999px;opacity:0;pointer-events:none;";
    document.body.appendChild(input);
  }
  input.onchange = function (e) {
    var file = e.target.files && e.target.files[0];
    input.value = "";
    if (!file) return;
    var done = function (dataUrl) {
      if (!dataUrl) return;
      if (targetKey) {
        if (window.__akiniSaveImageKey) window.__akiniSaveImageKey(targetKey, dataUrl);
        else {
          try {
            localStorage.setItem(targetKey, dataUrl);
          } catch (ex) {}
        }
      }
      if (callback) callback(dataUrl);
    };
    if (/avatar/i.test(targetKey || "")) window.__akiniCropImageSquare(file, done, 300);
    else window.__akiniReadImageOriginal(file, done);
  };
  input.click();
};
